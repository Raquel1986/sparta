package com.sparta.dao;

import com.sparta.model.Provider;

public interface ProviderDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.

    int insertNewProvider(Provider provider);

    Provider selectProviderByName(String name);

}

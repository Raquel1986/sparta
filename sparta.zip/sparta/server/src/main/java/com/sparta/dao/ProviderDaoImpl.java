package com.sparta.dao;

import com.sparta.model.Provider;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository("providerDao")
public class ProviderDaoImpl implements ProviderDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    private final Map<String, Provider> fakeDatabase;

    public ProviderDaoImpl() {
        this.fakeDatabase = new HashMap<>();
    }

    @Override
    public int insertNewProvider(Provider provider) {
        fakeDatabase.put(provider.getName(), provider);
        return 1;
    }

    @Override
    public Provider selectProviderByName(String name) {
        return fakeDatabase.get(name);
    }

}

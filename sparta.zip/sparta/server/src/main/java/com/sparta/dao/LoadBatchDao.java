package com.sparta.dao;

import com.sparta.model.LoadBatch;

public interface LoadBatchDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    int insertNewLoadBatch(LoadBatch loadBatch);

}

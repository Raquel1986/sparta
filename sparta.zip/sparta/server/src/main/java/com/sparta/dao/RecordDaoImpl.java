package com.sparta.dao;

import com.sparta.model.Record;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("recordDao")
public class RecordDaoImpl implements RecordDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    private final List<Record> fakeDatabase;

    public RecordDaoImpl() {
        this.fakeDatabase = new ArrayList<>();
    }

    @Override
    public int insertNewRecord(Record record) {
        this.fakeDatabase.add(record);
        return 1;
    }

}

package com.sparta.model;

import java.math.BigInteger;

public class Record {

    private BigInteger recordIndex;
    private BigInteger timestamp;
    private String city;
    private BigInteger numberBytesSensorData;
    private SensorCollection sensorsData;
    private BigInteger crc32SensorsData;

    public Record(BigInteger recordIndex, BigInteger timestamp,
                  String city, BigInteger numberBytesSensorData,
                  SensorCollection sensorsData, BigInteger crc32SensorsData) {
        this.recordIndex = recordIndex;
        this.timestamp = timestamp;
        this.city = city;
        this.numberBytesSensorData = numberBytesSensorData;
        this.sensorsData = sensorsData;
        this.crc32SensorsData = crc32SensorsData;
    }

    public BigInteger getRecordIndex() {
        return recordIndex;
    }

    public void setRecordIndex(BigInteger recordIndex) {
        this.recordIndex = recordIndex;
    }

    public BigInteger getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(BigInteger timestamp) {
        this.timestamp = timestamp;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public BigInteger getNumberBytesSensorData() {
        return numberBytesSensorData;
    }

    public void setNumberBytesSensorData(BigInteger numberBytesSensorData) {
        this.numberBytesSensorData = numberBytesSensorData;
    }

    public SensorCollection getSensorsData() {
        return sensorsData;
    }

    public void setSensorsData(SensorCollection sensorsData) {
        this.sensorsData = sensorsData;
    }

    public BigInteger getCrc32SensorsData() {
        return crc32SensorsData;
    }

    public void setCrc32SensorsData(BigInteger crc32SensorsData) {
        this.crc32SensorsData = crc32SensorsData;
    }
}

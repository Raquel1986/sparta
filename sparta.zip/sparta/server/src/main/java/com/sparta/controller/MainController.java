package com.sparta.controller;

import com.sparta.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
public class MainController {

    // This is the service for accessing the fake database.
    private final DataService dataService;

    @Autowired
    public MainController(DataService dataService) {
        this.dataService = dataService;
    }

    @PostMapping("/load/{provider}")
    public int load(@PathVariable("provider") String provider, @RequestBody byte[] content) throws IOException {
        dataService.transformData(provider, content); // Transform the data from the array of bytes.
        return dataService.getNumberOfRecords(provider); // Total of records from the current reading.
    }

    @GetMapping("/data/{provider}/total")
    public int total(@PathVariable("provider") String provider) {
        return dataService.getTotalReadingsByProvider(provider); // Total of readings from the current provider.
    }

}

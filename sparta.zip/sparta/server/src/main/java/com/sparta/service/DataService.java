package com.sparta.service;

import com.sparta.dao.*;
import com.sparta.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class DataService {

    // These are for accessing the fake database, which is in memory.
    private final SensorDao sensorDao;
    private final SensorCollectionDao sensorCollectionDao;
    private final RecordDao recordDao;
    private final LoadBatchDao loadBatchDao;
    private final ProviderDao providerDao;

    // I'm using the list of bytes as a global variable because I need to be able to modify it from everywhere.
    private List<Byte> listBytes;

    @Autowired
    public DataService(
            @Qualifier("sensorDao") SensorDao sensorDao,
            @Qualifier("sensorCollectionDao") SensorCollectionDao sensorCollectionDao,
            @Qualifier("recordDao") RecordDao recordDao,
            @Qualifier("loadBatchDao") LoadBatchDao loadBatchDao,
            @Qualifier("providerDao") ProviderDao providerDao) {
        this.sensorDao = sensorDao;
        this.sensorCollectionDao = sensorCollectionDao;
        this.recordDao = recordDao;
        this.loadBatchDao = loadBatchDao;
        this.providerDao = providerDao;
    }

    public void transformData(String nameProvider, byte[] content) {

        // I convert the array to a list because it's easier to operate with lists.
        this.listBytes = convertBytesToList(content);

        // Obtain the LoadBatch data.
        BigInteger numberOfRecords = getNextInteger(8);
        List<Record> records = getNextRecords(numberOfRecords);
        LoadBatch loadBatch = new LoadBatch(numberOfRecords, records);
        // Insert in the fake database.
        loadBatchDao.insertNewLoadBatch(loadBatch);

        // Build the provider info, which I'm going to need in order to know the total of readings.
        Provider provider = providerDao.selectProviderByName(nameProvider);

        // If it is the first message sent by this provider.
        if (provider == null) {
            provider = new Provider(nameProvider, new ArrayList<>());
        }

        // Add the current LoadBatch into the Provider instance.
        List<LoadBatch> loadBatchList = provider.getLoadBatchList();
        loadBatchList.add(loadBatch);
        provider.setLoadBatchList(loadBatchList);

        // Insert in the fake database.
        providerDao.insertNewProvider(provider);

    }

    // Total of records from the current reading.
    public Integer getNumberOfRecords(String nameProvider) {
        LoadBatch loadBatch = selectLoadBatch(nameProvider);
        BigInteger numberOfRecords = loadBatch.getNumberOfRecords();
        return numberOfRecords.intValueExact();
    }

    // Total of readings from the current provider.
    public Integer getTotalReadingsByProvider(String nameProvider) {
        Provider provider = providerDao.selectProviderByName(nameProvider);
        List<LoadBatch> list = provider.getLoadBatchList();
        return list.size();
    }

    // Last LoadBach from the current provider.
    private LoadBatch selectLoadBatch(String nameProvider) {
        Provider provider = providerDao.selectProviderByName(nameProvider);
        List<LoadBatch> list = provider.getLoadBatchList();
        return list.get(list.size() - 1);
    }

    // Obtain the record info from the array.
    private Record getNextRecord() {

        BigInteger recordIndex = getNextInteger(8);
        BigInteger timestamp = getNextInteger(8);

        // Obtain city
        BigInteger numberOfBytes = getNextInteger(4);
        String city = getNextString(numberOfBytes);

        // Number of bytes used in following sensorData section
        BigInteger numberBytesSensorData = getNextInteger(4);

        // Obtain SensorCollection
        SensorCollection sensorsData = getSensorCollection();

        // crc32 of all bytes present in the sensorData section
        BigInteger crc32SensorsData = getNextInteger(8);

        Record record = new Record(recordIndex, timestamp, city, numberBytesSensorData, sensorsData, crc32SensorsData);

        // Insert in the fake database.
        recordDao.insertNewRecord(record);

        return record;

    }

    // Obtain the SensorCollection info from the array.
    private SensorCollection getSensorCollection() {
        BigInteger numberOfSensors = getNextInteger(4);
        List<Sensor> sensors = getSensors(numberOfSensors);
        SensorCollection sensorsData = new SensorCollection(numberOfSensors, sensors);

        // Insert in the fake database.
        sensorCollectionDao.insertNewSensorCollection(sensorsData);

        return sensorsData;
    }


    // Extract the sensor info from the array of bytes
    private Sensor getNextSensor() {
        BigInteger numberOfBytes = getNextInteger(4);
        String idSensor = getNextString(numberOfBytes);
        BigInteger measure = getNextInteger(4);
        Sensor sensor = new Sensor(idSensor, measure);

        // Insert in the fake database.
        sensorDao.insertNewSensor(sensor);

        return sensor;
    }

    // Obtain the list of records from the array.
    private List<Record> getNextRecords(BigInteger numberOfRecords) {
        List<Record> records = new ArrayList<>();
        for (int i = 0; i < numberOfRecords.intValueExact(); i++) {
            records.add(getNextRecord());
        }
        return records;
    }

    // Obtain the list of sensors from the array.
    private List<Sensor> getSensors(BigInteger numberOfSensors) {
        List<Sensor> sensors = new ArrayList<>();
        for (int i = 0; i < numberOfSensors.intValueExact(); i++) {
            sensors.add(getNextSensor());
        }
        return sensors;
    }

    // Obtain the next group of bytes from the array.
    private byte[] getNextBytes(Integer numberOfBytes) {
        List<Byte> bytesToList = listBytes.subList(0, numberOfBytes);
        listBytes = listBytes.subList(numberOfBytes, listBytes.size());
        return convertListToBytes(bytesToList);
    }

    // Obtain the next number from the array (int32 or int64, depending of numberOfBytes).
    private BigInteger getNextInteger(Integer numberOfBytes) {
        byte[] bytes = getNextBytes(numberOfBytes);
        return new BigInteger(bytes);
    }

    // Obtain the next String from the array.
    private String getNextString(BigInteger numberOfBytes) {
        byte[] bytes = getNextBytes(numberOfBytes.intValueExact());
        return new String(bytes, StandardCharsets.UTF_8);
    }

    // Convert a list of Byte into an array of byte.
    private static byte[] convertListToBytes(List<Byte> list) {
        byte[] bytes = new byte[list.size()];
        for (int i = 0; i < list.size(); i++) {
            bytes[i] = list.get(i);
        }
        return bytes;
    }

    // Convert an array of byte into a list of Byte.
    private static List<Byte> convertBytesToList(byte[] bytes) {
        final List<Byte> list = new ArrayList<>();
        for (byte b : bytes) {
            list.add(b);
        }
        return list;
    }

}

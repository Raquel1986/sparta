package com.sparta.model;

import java.util.List;

public class Provider {

    private String name;
    private List<LoadBatch> loadBatchList;

    public Provider(String name, List<LoadBatch> loadBatchList) {
        this.name = name;
        this.loadBatchList = loadBatchList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<LoadBatch> getLoadBatchList() {
        return loadBatchList;
    }

    public void setLoadBatchList(List<LoadBatch> loadBatchList) {
        this.loadBatchList = loadBatchList;
    }
}

package com.sparta.dao;

import com.sparta.model.SensorCollection;

public interface SensorCollectionDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    int insertNewSensorCollection(SensorCollection sensorCollection);

}

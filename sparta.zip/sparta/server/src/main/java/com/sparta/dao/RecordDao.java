package com.sparta.dao;

import com.sparta.model.Record;

public interface RecordDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    int insertNewRecord(Record record);

}

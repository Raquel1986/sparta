package com.sparta.model;

import java.math.BigInteger;
import java.util.List;

public class SensorCollection {

    private BigInteger numberOfSensors;
    private List<Sensor> sensors;

    public SensorCollection(BigInteger numberOfSensors, List<Sensor> sensors) {
        this.numberOfSensors = numberOfSensors;
        this.sensors = sensors;
    }

    public BigInteger getNumberOfSensors() {
        return numberOfSensors;
    }

    public void setNumberOfSensors(BigInteger numberOfSensors) {
        this.numberOfSensors = numberOfSensors;
    }

    public List<Sensor> getSensors() {
        return sensors;
    }

    public void setSensors(List<Sensor> sensors) {
        this.sensors = sensors;
    }
}

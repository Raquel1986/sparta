package com.sparta.dao;

import com.sparta.model.LoadBatch;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("loadBatchDao")
public class LoadBatchDaoImpl implements LoadBatchDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    private final List<LoadBatch> fakeDatabase;

    public LoadBatchDaoImpl() {
        this.fakeDatabase = new ArrayList<>();
    }

    @Override
    public int insertNewLoadBatch(LoadBatch loadBatch) {
        this.fakeDatabase.add(loadBatch);
        return 1;
    }

}

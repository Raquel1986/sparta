package com.sparta.model;

import java.math.BigInteger;
import java.util.List;

public class LoadBatch {

    private BigInteger numberOfRecords;
    private List<Record> records;

    public LoadBatch(BigInteger numberOfRecords, List<Record> records) {
        this.numberOfRecords = numberOfRecords;
        this.records = records;
    }

    public BigInteger getNumberOfRecords() {
        return numberOfRecords;
    }

    public void setNumberOfRecords(BigInteger numberOfRecords) {
        this.numberOfRecords = numberOfRecords;
    }

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }
}

package com.sparta.dao;

import com.sparta.model.Sensor;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository("sensorDao")
public class SensorDaoImpl implements SensorDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    private final Map<String, Sensor> fakeDatabase;

    public SensorDaoImpl() {
        fakeDatabase = new HashMap<>();
    }

    @Override
    public int insertNewSensor(Sensor newSensor) {
        fakeDatabase.put(newSensor.getId(), newSensor);
        return 1;
    }

}

package com.sparta.model;

import java.math.BigInteger;

public class Sensor {
    private String id;
    private BigInteger measure;

    public Sensor(String id, BigInteger measure) {
        this.id = id;
        this.measure = measure;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public BigInteger getMeasure() {
        return measure;
    }

    public void setMeasure(BigInteger measure) {
        this.measure = measure;
    }
}

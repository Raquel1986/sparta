package com.sparta.dao;

import com.sparta.model.SensorCollection;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("sensorCollectionDao")
public class SensorCollectionDaoImpl implements SensorCollectionDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    private final List<SensorCollection> fakeDatabase;

    public SensorCollectionDaoImpl() {
        this.fakeDatabase = new ArrayList<>();
    }

    @Override
    public int insertNewSensorCollection(SensorCollection sensorCollection) {
        this.fakeDatabase.add(sensorCollection);
        return 1;
    }

}

package com.sparta.dao;

import com.sparta.model.Sensor;

public interface SensorDao {

    // I'm not using any real database. This is just for accessing the fake database, which is in memory.
    int insertNewSensor(Sensor sensor);

}
